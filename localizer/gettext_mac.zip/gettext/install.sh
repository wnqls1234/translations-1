#!/bin/bash
cp ./bin/* /usr/local/bin
cp ./lib/*.* /usr/local/lib
