Install gettext tools on Mac OS X
=================================

- Open a new terminal window
- Navigate to this folder
- Type "sudo ./install.h"
- This should copy the relevant files to /usr/local.